package LucasPires;

public class LPC11 {

	public static void main(String[] args) {
		System.out.println("**************************************************");
		System.out.println("* Aluno: Lucas Pires Cabral - RA 0024413                 *");
		System.out.println("* Classe LPC11 -  Contar de 1 a 10.              *");
		System.out.println("**************************************************");

		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
	}

}