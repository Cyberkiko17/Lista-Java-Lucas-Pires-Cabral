package LucasPires;


public class LPC16 {

	public static void main(String[] args) {
		System.out.println("**************************************************************");
		System.out.println("* Aluno: Lucas Pires Cabral - RA 0024413                             *");
		System.out.println("* Classe LPC16 -    Contagem regressiva.                     *");
		System.out.println("**************************************************************");

		System.out.println("CONTAGEM REGRESSIVA:");

		for (int i = 10; i >= 1; i--) {
			System.out.println(i);
		}
	}

}