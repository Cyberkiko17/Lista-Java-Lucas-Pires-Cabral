package LucasPires;

public class LPC36 {

	public static void main(String[] args) {
		System.out.println("**************************************************************");
		System.out.println("* Aluno: Lucas Pires Cabral - RA 0024413                             *");
		System.out.println("* Classe LPC36 -     Contagem regressiva de 10 até 1         *");
		System.out.println("**************************************************************");

		int i = 10;
		System.out.println("Iniciando contagem regressiva:\n");

		do {
			System.out.print(i + ", ");
			i--;

		} while (i != 0);

	}

}