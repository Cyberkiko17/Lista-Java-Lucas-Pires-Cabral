package LucasPires;

public class LPC21 {

	public static void main(String[] args) {
		System.out.println("**************************************************************");
		System.out.println("* Aluno: Lucas Pires Cabral - RA 0024413                             *");
		System.out.println("* Classe LPC21 -      Contar até 10 com while.               *");
		System.out.println("**************************************************************");

		int i = 1;
		while (i <= 10) {
			System.out.print(i + " ");
			i++;
		}
	}

}